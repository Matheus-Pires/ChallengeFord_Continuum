package model;

public class Usuario {
	
	private Integer id;
	private String nome;
	private String sobrenome;
	private Integer idade;
	private String CPF;
	private String telephone;
	private String email;
	
	public Usuario(){
		super();
	}
	
	
	
	public Usuario(Integer id, String nome, String sobrenome, Integer idade, String CPF, String telephone, String email) {
		super();
		this.id = id;
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.idade = idade;
		this.CPF = CPF;
		this.telephone = telephone;
		this.email = email;
	}



	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	
	public Integer getIdade() {
		return idade;
	}
	public void setIdade(Integer idade) {
		this.idade = idade;
	}
	
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String CPF) {
		this.CPF = CPF;
	}
	
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "Usuario:\nid = " + id + "\nnome = " + nome + "\nsobrenome = " + sobrenome + "\nidade = " + idade + "\nCPF = " + CPF + "\ntelephone = " + telephone + "\nemail = " + email;
	}
	
	
	

}
