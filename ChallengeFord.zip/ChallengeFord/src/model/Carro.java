package model;

public class Carro {
	
	private Integer id;
	private String model;
	private String placa;
	private String ano;
	private Integer userID;
	
	public Carro(){
		super();
	}
	
	public Carro(Integer id, String model, String placa, String ano, Integer userID) {
		super();
		this.id = id;
		this.model = model;
		this.placa = placa;
		this.ano = ano;
		this.userID = userID;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	
	public String getAno() {
		return ano;
	}
	public void setAno(String ano) {
		this.ano = ano;
	}
	
	public Integer getUserID() {
		return userID;
	}
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	
	@Override
	public String toString() {
		return "Carro:\nid = " + id + "\nmodel = " + model + "\nplaca = " + placa + "\nano = " + ano + "\nuser = " + userID;
	}
	
	

}
