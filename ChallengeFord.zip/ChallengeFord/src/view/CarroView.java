package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.CarroDAO;
import dao.GerenciadorDB;
import dao.UsuariosDAO;
import model.Carro;
import model.Usuario;

public class CarroView extends JFrame {
	
	Statement commandoSQL;
	
	private JLabel lblID;
	private JLabel lblModel;
	private JLabel lblPlaca;
	private JLabel lblAno;
	private JLabel lblUserID;
	
	private JTextField txtID;
	private JTextField txtModel;
	private JTextField txtPlaca;
	private JTextField txtAno;
	private JTextField txtUserID;
	
	private JButton btnCadastrar;
	private JButton btnLimpar;
	private JButton btnExcluir;
	private JButton btnLocalizar;
	
	private JPanel pnlButton;
	private JPanel pnlInput;
	
	public CarroView() {
		super("Cadastro de Carro");
		this.setSize(350, 350);
		this.setLayout(new GridBagLayout());
		
		pnlInput = new JPanel();
		pnlInput.setLayout(new GridBagLayout());
		GridBagConstraints posicoes = new GridBagConstraints();
		posicoes.insets = new Insets(4,4,4,4);
		posicoes.anchor = posicoes.LINE_START;
		
		posicoes.gridx = 0;
		posicoes.gridy = 0;
		lblID = new JLabel("ID ");
		pnlInput.add(lblID, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 0;
		txtID = new JTextField(10);
		pnlInput.add(txtID, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 1;
		lblModel = new JLabel("Modelo ");
		pnlInput.add(lblModel, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 1;
		txtModel = new JTextField(10);
		pnlInput.add(txtModel, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 2;
		lblPlaca = new JLabel("Placa ");
		pnlInput.add(lblPlaca, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 2;
		txtPlaca = new JTextField(10);
		pnlInput.add(txtPlaca, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 3;
		lblAno = new JLabel("Ano ");
		pnlInput.add(lblAno, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 3;
		txtAno = new JTextField(10);
		pnlInput.add(txtAno, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 4;
		lblUserID = new JLabel("UserID ");
		pnlInput.add(lblUserID, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 4;
		txtUserID = new JTextField(10);
		pnlInput.add(txtUserID, posicoes);
		
		pnlButton = new JPanel();
		pnlButton.setLayout(new GridBagLayout());
		
		posicoes.gridx = 0;
		posicoes.gridy = 0;
		btnCadastrar = new JButton ("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evento) {
				Carro carro = new Carro();
				Usuario user = new Usuario();
				carro.setId(Integer.parseInt(txtID.getText()));
				carro.setModel(txtModel.getText());
				carro.setPlaca(txtPlaca.getText());
				carro.setAno(txtAno.getText());
				carro.setUserID(Integer.parseInt(txtUserID.getText()));
				
				UsuariosDAO Udao = new UsuariosDAO();
				user.setId(Integer.parseInt(txtUserID.getText()));
				
				if (Udao.localizar(user) != null) {
					CarroDAO dao = new CarroDAO();
					dao.inserir(carro);
					JOptionPane.showMessageDialog(null, "Carro do ID: " + txtID.getText() + " foi cadastrado");
				} else {
					JOptionPane.showMessageDialog(null, "Usuario do ID: " + txtUserID.getText() + " nao foi encontrado");
				}
			}
		});
		pnlButton.add(btnCadastrar, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 1;
		btnExcluir = new JButton ("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evento) {
				Carro carro = new Carro();
				carro.setId(Integer.parseInt(txtID.getText()));
				
				CarroDAO dao = new CarroDAO();
				dao.deletar(carro);
				JOptionPane.showMessageDialog(null, "Carro do ID: " + txtID.getText() + " foi removido");
				
				txtID.setText("");
				txtModel.setText("");
				txtPlaca.setText("");
				txtAno.setText("");
				txtUserID.setText("");
			}
		});
		pnlButton.add(btnExcluir, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 0;
		btnLimpar = new JButton ("Atualizar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evento) {
				Carro carro = new Carro();
				carro.setId(Integer.parseInt(txtID.getText()));
				carro.setModel(txtModel.getText());
				carro.setPlaca(txtPlaca.getText());
				carro.setAno(txtAno.getText());
				carro.setUserID(Integer.parseInt(txtUserID.getText()));
				
				CarroDAO dao = new CarroDAO();
				dao.atualizar(carro);
				JOptionPane.showMessageDialog(null, "Carro do ID: " + txtID.getText() + " foi atualizado");
			}
		});
		pnlButton.add(btnLimpar, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 1;
		btnLocalizar = new JButton ("Localizar");
		btnLocalizar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evento) {
				Carro carro = new Carro();
				carro.setId(Integer.parseInt(txtID.getText()));
				
				CarroDAO dao = new CarroDAO();
				dao.localizar(carro);
				
				txtAno.setText(carro.getAno());
				txtModel.setText(carro.getModel());
				txtPlaca.setText(carro.getPlaca());
				txtUserID.setText(Integer.toString(carro.getUserID()));
				
				JOptionPane.showMessageDialog(null, "Carro do ID: " + txtID.getText() + " foi localizado");

			}
		});
		pnlButton.add(btnLocalizar,posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 0;
		posicoes.anchor = posicoes.CENTER;
		this.add(pnlInput, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 1;
		this.add(pnlButton, posicoes);
		
	}

}
