package view;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;

import dao.GerenciadorDB;

public class MainView extends JFrame {
	
	private JButton btnCarro;
	private JButton btnUsuario;
	
	public MainView() {

		super("Pagina Inicial");
		this.setLayout(new FlowLayout());
		this.setSize(300, 200);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		btnCarro = new JButton("Carro");
		btnCarro.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evento) {
				CarroView janela = new CarroView();
				janela.setVisible(true);
			}
		});
		
		btnUsuario = new JButton("Usuario");
		btnUsuario.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evento) {
				UsuarioView janela = new UsuarioView();
				janela.setVisible(true);
				
			}
		});
		
		this.add(btnCarro);
		this.add(btnUsuario);
	}
	
	public static Connection obterConexao () {
		Connection conexao = null;
		
		try {
			conexao = DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:orcl","rm80113","190499");
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		return conexao;
	}
	
	public static void main(String [] args) {
		
		if(GerenciadorDB.obterConexao() != null) {
			MainView janela = new MainView();
			janela.setVisible(true);
		} else {
			System.out.print("ERRO AO TENTAR CONECTAR");
		}
	}

}