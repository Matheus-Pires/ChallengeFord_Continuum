package view;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;

import dao.GerenciadorDB;

public class MainView extends JFrame {
	
	private JButton btnCarro;
	private JButton btnUsuario;
	
	public MainView() {

		super("Pagina Inicial");
		this.setLayout(new FlowLayout());
		this.setSize(300, 200);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		btnCarro = new JButton("Carro");
		btnCarro.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evento) {
				CarroView janela = new CarroView();
				janela.setVisible(true);
			}
		});
		
		btnUsuario = new JButton("Usuario");
		btnUsuario.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evento) {
				UsuarioView janela = new UsuarioView();
				janela.setVisible(true);
				
			}
		});
		
		this.add(btnCarro);
		this.add(btnUsuario);
	}
	
	public static void main(String [] args) {
		
		Connection conexao;
		conexao = GerenciadorDB.obterConexao();
		
		
		if(conexao != null) {
			try {
				MainView janela = new MainView();
				janela.setVisible(true);
				conexao.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			System.out.print("ERRO AO TENTAR CONECTAR");
		}
	}

}