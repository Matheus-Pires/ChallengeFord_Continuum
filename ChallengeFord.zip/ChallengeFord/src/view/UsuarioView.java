package view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.UsuariosDAO;
import model.Usuario;

public class UsuarioView extends JFrame {
	
	Statement commandoSQL;
	
	private JLabel lblID;
	private JLabel lblNome;
	private JLabel lblSobrenome;
	private JLabel lblIdade;
	private JLabel lblCPF;
	private JLabel lblTelephone;
	private JLabel lblEmail;
	
	private JTextField txtID;
	private JTextField txtNome;
	private JTextField txtSobrenome;
	private JTextField txtIdade;
	private JTextField txtCPF;
	private JTextField txtTelephone;
	private JTextField txtEmail;
	
	private JButton btnCadastrar;
	private JButton btnLimpar;
	private JButton btnExcluir;
	private JButton btnLocalizar;
	
	private JPanel pnlButton;
	private JPanel pnlInput;
	
	public UsuarioView() {
		super("Cadastro de Usuario");
		this.setSize(350, 400);
		this.setLayout(new GridBagLayout());
		
		pnlInput = new JPanel();
		pnlInput.setLayout(new GridBagLayout());
		
		GridBagConstraints posicoes = new GridBagConstraints();
		posicoes.insets = new Insets(4,4,4,4);
		posicoes.anchor = posicoes.LINE_START;
		
		posicoes.gridx = 0;
		posicoes.gridy = 0;
		lblID = new JLabel("ID ");
		pnlInput.add(lblID, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 0;
		txtID = new JTextField(10);
		pnlInput.add(txtID, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 1;
		lblNome = new JLabel("Nome ");
		pnlInput.add(lblNome, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 1;
		txtNome = new JTextField(10);
		pnlInput.add(txtNome, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 2;
		lblSobrenome = new JLabel("Sobrenome ");
		pnlInput.add(lblSobrenome, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 2;
		txtSobrenome = new JTextField(10);
		pnlInput.add(txtSobrenome, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 3;
		lblIdade = new JLabel("idade ");
		pnlInput.add(lblIdade, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 3;
		txtIdade = new JTextField(10);
		pnlInput.add(txtIdade, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 4;
		lblCPF = new JLabel("CPF ");
		pnlInput.add(lblCPF, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 4;
		txtCPF = new JTextField(10);
		pnlInput.add(txtCPF, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 5;
		lblTelephone = new JLabel("Telephone ");
		pnlInput.add(lblTelephone, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 5;
		txtTelephone = new JTextField(10);
		pnlInput.add(txtTelephone, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 6;
		lblEmail = new JLabel("email ");
		pnlInput.add(lblEmail, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 6;
		txtEmail = new JTextField(10);
		pnlInput.add(txtEmail, posicoes);
		
		pnlButton = new JPanel();
		pnlButton.setLayout(new GridBagLayout());
		
		posicoes.gridx = 0;
		posicoes.gridy = 0;
		btnCadastrar = new JButton ("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evento) {
				Usuario user = new Usuario();
				user.setId(Integer.parseInt(txtID.getText()));
				user.setNome(txtNome.getText());
				user.setSobrenome(txtSobrenome.getText());
				user.setCPF(txtCPF.getText());
				user.setEmail(txtEmail.getText());
				user.setIdade(Integer.parseInt(txtIdade.getText()));
				user.setTelephone(txtTelephone.getText());
				
				UsuariosDAO dao = new UsuariosDAO();
				dao.inserir(user);
				JOptionPane.showMessageDialog(null, "Usuario Inserido!");
			}
		});
		pnlButton.add(btnCadastrar, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 1;
		btnExcluir = new JButton ("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evento) {
				Usuario user = new Usuario();
				user.setId(Integer.parseInt(txtID.getText()));
				
				UsuariosDAO dao = new UsuariosDAO();
				dao.deletar(user);
				JOptionPane.showMessageDialog(null, "Usuario Removido!");
			}
		});
		pnlButton.add(btnExcluir, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 0;
		btnLimpar = new JButton ("Atualizar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evento) {
				Usuario user = new Usuario();
				user.setId(Integer.parseInt(txtID.getText()));
				user.setNome(txtNome.getText());
				user.setEmail(txtEmail.getText());
				user.setSobrenome(txtSobrenome.getText());
				user.setCPF(txtCPF.getText());
				user.setIdade(Integer.parseInt(txtIdade.getText()));
				user.setTelephone(txtTelephone.getText());
				
				UsuariosDAO dao = new UsuariosDAO();
				dao.atualizar(user);
				JOptionPane.showMessageDialog(null, "Usuario Atualizado!");

			}
		});
		pnlButton.add(btnLimpar, posicoes);
		
		posicoes.gridx = 1;
		posicoes.gridy = 1;
		btnLocalizar = new JButton ("Localizar");
		btnLocalizar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent evento) {
				Usuario user = new Usuario();
				user.setId(Integer.parseInt(txtID.getText()));
				
				UsuariosDAO dao = new UsuariosDAO();
				dao.localizar(user);
				
				txtNome.setText(user.getNome());
				txtSobrenome.setText(user.getSobrenome());
				txtCPF.setText(user.getCPF());
				txtIdade.setText(Integer.toString(user.getIdade()));
				txtTelephone.setText(user.getTelephone());
				txtEmail.setText(user.getEmail());
				
				JOptionPane.showMessageDialog(null, "Usuario Localizado!");

			}
		});
		pnlButton.add(btnLocalizar,posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 0;
		posicoes.anchor = posicoes.CENTER;
		this.add(pnlInput, posicoes);
		
		posicoes.gridx = 0;
		posicoes.gridy = 1;
		this.add(pnlButton, posicoes);
		
	}

}
