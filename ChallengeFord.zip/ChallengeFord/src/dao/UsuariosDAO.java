package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Usuario;

public class UsuariosDAO {
	private Connection conexao;
	
	public void inserir(Usuario user) {
		// Iniciando a sess�o com o banco de dadsos
		conexao = GerenciadorDB.obterConexao();
		// Criando um PreparedStatement que evai servir para exeutar nossas instru��es SQL
		PreparedStatement comandoSQL = null;
		
		try {
			//Preparando a nossa instru��o, colocando o sinalk de > nos lugares onde prtendemos preencher com valores posteriormente
			comandoSQL = conexao.prepareStatement("INSERT INTO USUARIOS (USER_ID, NOME, S_NOME, CPF, EMAIL, IDADE, TELEFONE) VALUES (?,?,?,?,?,?,?)");
			// Preenchendo os par�metros que estavam marcados com o sinal de ?
			comandoSQL.setInt(1, user.getId());
			comandoSQL.setString(2, user.getNome());
			comandoSQL.setString(3, user.getSobrenome());
			comandoSQL.setString(4, user.getCPF());
			comandoSQL.setString(5, user.getEmail());
			comandoSQL.setInt(6, user.getIdade());
			comandoSQL.setString(7, user.getTelephone());
			// A linha abaixo e respons�vel por EXECUTAR a intru��o 
			comandoSQL.executeUpdate();
			conexao.close();
			comandoSQL.close();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void atualizar(Usuario user){
		conexao = GerenciadorDB.obterConexao();
		
		PreparedStatement comandoSQL = null;
		
		try {
			comandoSQL = conexao.prepareStatement("UPDATE USUARIOS SET USER_ID=?, NOME=?, S_NOME=?, CPF=?, EMAIL=?, IDADE=?, TELEFONE=?");
			
			comandoSQL.setInt(1, user.getId());
			comandoSQL.setString(2, user.getNome());
			comandoSQL.setString(3, user.getSobrenome());
			comandoSQL.setString(4, user.getCPF());
			comandoSQL.setString(5, user.getEmail());
			comandoSQL.setInt(6, user.getIdade());
			comandoSQL.setString(7, user.getTelephone());
			
			comandoSQL.executeUpdate();
			comandoSQL.close();

		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deletar(Usuario user){
		conexao = GerenciadorDB.obterConexao();
		
		PreparedStatement comandoSQL = null;
		
		try {
			comandoSQL = conexao.prepareStatement("DELETE FROM FORNECEDOR WHERE ID_FORNECEDOR=?");
			
			comandoSQL.setInt(1, user.getId());
			
			comandoSQL.executeUpdate();
			conexao.close();
			comandoSQL.close();

		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Usuario localizar(Usuario user) {
		conexao = GerenciadorDB.obterConexao();
		PreparedStatement comandoSQL = null;
		
		try {
			comandoSQL = conexao.prepareStatement("SELECT * FROM FORNECEDOR WHERE ID_FORNECEDOR=?");
			
			comandoSQL.setInt(1, user.getId());
			ResultSet resultados = comandoSQL.executeQuery();
			
			if (resultados.next()) {
				user.setNome(resultados.getString(2));
				user.setSobrenome(resultados.getString(3));
				user.setCPF(resultados.getString(4));
				user.setEmail(resultados.getString(5));
				user.setIdade(resultados.getInt(6));
				user.setTelephone(resultados.getString(7));
			}
			
			conexao.close();
			comandoSQL.close();
		
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		return user;
	}
}

