package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Carro;

public class CarroDAO {
private Connection conexao;
	
	public void inserir(Carro carro) {
		// Iniciando a sess�o com o banco de dadsos
		conexao = GerenciadorDB.obterConexao();
		// Criando um PreparedStatement que evai servir para exeutar nossas instru��es SQL
		PreparedStatement comandoSQL = null;
		
		try {
			//Preparando a nossa instru��o, colocando o sinalk de > nos lugares onde prtendemos preencher com valores posteriormente
			comandoSQL = conexao.prepareStatement("INSERT INTO VEICULOS (VEICULO_ID, MODELO, ANO, PLACA, USER_ID) VALUES (?,?,?,?,?)");
			// Preenchendo os par�metros que estavam marcados com o sinal de ?
			comandoSQL.setInt(1, carro.getId());
			comandoSQL.setString(2, carro.getModel());
			comandoSQL.setString(3, carro.getAno());
			comandoSQL.setString(4, carro.getPlaca());
			comandoSQL.setInt(5, carro.getUserID());
			
			// A linha abaixo e respons�vel por EXECUTAR a intru��o 
			comandoSQL.executeUpdate();
			conexao.close();
			comandoSQL.close();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void atualizar(Carro carro){
		conexao = GerenciadorDB.obterConexao();
		
		PreparedStatement comandoSQL = null;
		
		try {
			comandoSQL = conexao.prepareStatement("UPDATE VEICULOS SET VEICULO_ID=?, MODELO=?, ANO=?, PLACA=?, USER_ID=?");
			
			comandoSQL.setInt(1, carro.getId());
			comandoSQL.setString(2, carro.getModel());
			comandoSQL.setString(3, carro.getAno());
			comandoSQL.setString(4, carro.getPlaca());
			comandoSQL.setInt(5, carro.getUserID());
			
			comandoSQL.executeUpdate();
			comandoSQL.close();

		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deletar(Carro carro){
		conexao = GerenciadorDB.obterConexao();
		
		PreparedStatement comandoSQL = null;
		
		try {
			comandoSQL = conexao.prepareStatement("DELETE FROM FORNECEDOR WHERE ID_FORNECEDOR=?");
			
			comandoSQL.setInt(1, carro.getId());
			
			comandoSQL.executeUpdate();
			conexao.close();
			comandoSQL.close();

		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Carro localizar(Carro Carro) {
		conexao = GerenciadorDB.obterConexao();
		PreparedStatement comandoSQL = null;
		
		try {
			comandoSQL = conexao.prepareStatement("SELECT * FROM FORNECEDOR WHERE ID_FORNECEDOR=?");
			
			comandoSQL.setInt(1, Carro.getId());
			ResultSet resultados = comandoSQL.executeQuery();
			
			if (resultados.next()) {
				Carro.setModel(resultados.getString(2));
				Carro.setAno(resultados.getString(3));
				Carro.setPlaca(resultados.getString(4));
				Carro.setUserID(Integer.parseInt(resultados.getString(5)));
			}
			
			conexao.close();
			comandoSQL.close();
		
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		return Carro;
	}
}
