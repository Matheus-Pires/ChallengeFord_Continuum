package dao;
import java.sql.*;


public class GerenciadorDB {
	public static Connection obterConexao () {
		Connection conexao = null;
		
		try {
			conexao = DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:orcl","rm80113","190499");
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		return conexao;
	}
}
